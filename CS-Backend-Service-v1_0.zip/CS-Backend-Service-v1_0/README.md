# ClearSight Backend (v1.0)
Express/Node.js scaffold aligning with CS-API-Specification-v1_0.md.
## Quick Start (dev)
1. `cp .env.example .env`
2. Edit DATABASE_URL if needed.
3. `npm ci`
4. `npm run dev`
## Docker
- `docker compose up --build`
## Health
- GET /health -> `{ ok: true }`
