import express from 'express';
import morgan from 'morgan';
import helmet from 'helmet';
import cors from 'cors';
import dotenv from 'dotenv';
import { pool } from './config/db.js';
import authRoutes from './routes/auth.js';
import boardRoutes from './routes/boards.js';
import stageRoutes from './routes/stages.js';
import eventRoutes from './routes/stageEvents.js';
import skuRoutes from './routes/sku.js';
import erpRoutes from './routes/erpSync.js';
import dashboardRoutes from './routes/dashboard.js';

dotenv.config();
const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('tiny'));

const PORT = process.env.PORT || 8080;

app.get('/health', (req, res) => res.json({ ok: true }));

app.use('/auth', authRoutes);
app.use('/boards', boardRoutes);
app.use('/stages', stageRoutes);
app.use('/stage-events', eventRoutes);
app.use('/sku', skuRoutes);
app.use('/erp-sync', erpRoutes);
app.use('/dashboard', dashboardRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'internal_error' });
});

app.listen(PORT, () => {
  console.log(`ClearSight API running on :${PORT}`);
});
