import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import BoardTracker from './components/BoardTracker';
import SKUOnboarding from './components/SKUOnboarding';
import ERPSyncView from './components/ERPSyncView';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/tracker" element={<BoardTracker />} />
        <Route path="/sku" element={<SKUOnboarding />} />
        <Route path="/erp" element={<ERPSyncView />} />
      </Routes>
    </Router>
  );
}
