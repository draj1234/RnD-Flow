import React from 'react';
export default function SKUOnboarding() {
  return <div>SKU Onboarding Placeholder</div>;
}
