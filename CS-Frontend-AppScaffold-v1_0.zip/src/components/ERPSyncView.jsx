import React from 'react';
export default function ERPSyncView() {
  return <div>ERP Sync View Placeholder</div>;
}
